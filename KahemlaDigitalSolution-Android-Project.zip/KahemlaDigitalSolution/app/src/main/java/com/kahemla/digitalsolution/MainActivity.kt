package com.kahemla.digitalsolution

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Service(val title:String,val desc:String,val icon:ImageVector)

class MainActivity:ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}} }

@Composable fun App(){
 val ctx=LocalContext.current; var tab by remember{mutableIntStateOf(0)}; var q by remember{mutableStateOf("")}
 val services=listOf(
  Service("RITA / e-RITA","Cheti cha kuzaliwa, kifo na verification",Icons.Default.Description),
  Service("CV & Documents","CV, barua, typing na nyaraka",Icons.Default.EditDocument),
  Service("Printing","Printing, photocopy na scanning",Icons.Default.Print),
  Service("Graphic Design","Poster, banner na matangazo",Icons.Default.Palette),
  Service("Digital Services","Huduma mbalimbali za kidijitali",Icons.Default.Computer),
  Service("Malipo","Lipa Namba 37713263",Icons.Default.CreditCard))
 MaterialTheme(colorScheme=lightColorScheme(primary=androidx.compose.ui.graphics.Color(0xFF1565C0))){
  Scaffold(topBar={TopAppBar(title={Column{Text("KAHEMLA DIGITAL SOLUTION",fontWeight=FontWeight.Bold,fontSize=18.sp);Text("ULIPO TUPO",fontSize=12.sp)}})},bottomBar={
   NavigationBar{listOf("Home" to Icons.Default.Home,"Huduma" to Icons.Default.List,"Malipo" to Icons.Default.CreditCard,"Wasiliana" to Icons.Default.Phone).forEachIndexed{ i,(t,ic)->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(ic,null)},label={Text(t)})}}
  }){pad-> when(tab){0->Home(Modifier.padding(pad),q,{q=it},services.filter{q.isBlank()||(it.title+it.desc).contains(q,true)},{ctx.startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:+255624525425")))},{ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/255624525425")))})
  1->Services(Modifier.padding(pad),services);2->Payment(Modifier.padding(pad));3->Contact(Modifier.padding(pad),{ctx.startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:+255624525425")))},{ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/255624525425")))})}}
 }
}

@Composable fun Home(m:Modifier,q:String,setQ:(String)->Unit,services:List<Service>,call:()->Unit,wa:()->Unit){Column(m.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
 Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)){Column(Modifier.padding(20.dp)){Text("Karibu!",fontSize=14.sp);Text("Huduma za kidijitali kwa urahisi.",fontSize=23.sp,fontWeight=FontWeight.Bold);Text("Fanya maombi yako ukiwa popote.")}}
 OutlinedTextField(q,setQ,Modifier.fillMaxWidth(),singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},placeholder={Text("Tafuta huduma...")})
 Text("Huduma Maarufu",fontSize=20.sp,fontWeight=FontWeight.Bold);services.forEach{ServiceCard(it)}
 Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(call,Modifier.weight(1f)){Icon(Icons.Default.Phone,null);Spacer(Modifier.width(6.dp));Text("Piga Simu")};OutlinedButton(wa,Modifier.weight(1f)){Text("WhatsApp")}}
}}
@Composable fun ServiceCard(s:Service){Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(s.icon,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(34.dp));Spacer(Modifier.width(14.dp));Column{Text(s.title,fontWeight=FontWeight.Bold);Text(s.desc,fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}}
@Composable fun Services(m:Modifier,s:List<Service>){Column(m.fillMaxSize().padding(16.dp)){Text("Huduma Zetu",fontSize=26.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));LazyVerticalGrid(columns=GridCells.Fixed(2),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){items(s){ServiceCard(it)}}}}
@Composable fun Payment(m:Modifier){Column(m.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){Text("Malipo",fontSize=28.sp,fontWeight=FontWeight.Bold);Card{Column(Modifier.padding(20.dp)){Text("Lipa Namba");Text("37713263",fontSize=32.sp,fontWeight=FontWeight.Bold);Text("KAHEMLA DIGITAL SOLUTION");Text("Wasiliana nasi baada ya malipo.")}}}}
@Composable fun Contact(m:Modifier,call:()->Unit,wa:()->Unit){Column(m.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){Text("Wasiliana Nasi",fontSize=28.sp,fontWeight=FontWeight.Bold);Text("0624 525 425",fontSize=25.sp,fontWeight=FontWeight.Bold);Button(call,Modifier.fillMaxWidth()){Icon(Icons.Default.Phone,null);Spacer(Modifier.width(8.dp));Text("Piga Simu")};OutlinedButton(wa,Modifier.fillMaxWidth()){Text("Fungua WhatsApp")};Text("ULIPO TUPO",fontWeight=FontWeight.Bold)}}
