# KAHEMLA DIGITAL SOLUTION
Android project using Kotlin + Jetpack Compose.

Version: 1.0.0
Version Code: 1
Package: com.kahemla.digitalsolution

Open in Android Studio, sync Gradle, then Build > Build APK(s).
Debug APK: app/build/outputs/apk/debug/app-debug.apk
